packet = load('C:\Users\Martijn\Documents\Stage\MATLAB\Arie\20220513-165536_677_decoded_new.mat');
load('20220513-165536_677_decoded_new.mat');
load('trlMat.mat');
longVar2 = longVar(:,2);

%% Martijn's code

%% Variables to fill in:


%Define a time (in ms) where it no longer is a freeze but transitions into sleeping. 
cutOffTime = 15000;     %Cut off value for standing still too long, running the script once will give you an unaltered heatmap of all the durations

%In general find packets without movement
packetSize = 50;      %Cutoff time needs to be divisible by packetSize, else you get an error

dTime=50;              %Delta Time, we are looking at time taken per 50mm of distance


%Define environment, for this we remove the first environment due to any startup issues that may arise. As soon as the mouse
%enters the second environment the experiment should've fully started
startEnv = longVar2(trlMat(2:end,1));
startRew = longVar2(trlMat(2:end,6));
endEnv = longVar2(trlMat(2:end,5));
endRew = longVar2(trlMat(2:end,8));
startStartEnv = startEnv - 100;
startStartRew = startRew - 50;
endEndEnv = endEnv + 50;
endEndRew = endRew + 50;

envPart1Size = 1650;   %Part1 currently 1500 of environment with 100 in front and 50 in the back
envPart2Size = 400;    %Part2 currently 300 of environment with 50 in front and behind

edgesPart1 = 0:dTime:envPart1Size;
edgesPart2 = 0:dTime:envPart2Size;

edges = -100:dTime:1950;        %Change these edges according to the environment (sum/configuration of the amount of edges in Part1 and Part2)
low = min(edges);
high = max(edges);


%These load colorbars for the graphs, if you adjust the colors above, you need to adjust the images in excell > snipping tool
color1i = imread('Color1.PNG'); %Red environment
color2i = imread('Color2.PNG'); %Blue environment
color3i = imread('Color3.PNG'); %Green environment
color1iPart1 = imread('Color1Part1.PNG'); %Red environment
color2iPart1 = imread('Color2Part1.PNG'); %Blue environment
color3iPart1 = imread('Color3Part1.PNG'); %Green environment
colorGeneral = imread('General1.png');    %General color for overal plots

color1iPart1 = imresize(color1iPart1, 2);
color2iPart1 = imresize(color2iPart1, 2);
color3iPart1 = imresize(color3iPart1, 2);

%% Calculate speed
longVar2 = longVar(:,2);
allEnvironments = size(trlMat(:,1),1);                      %Find the amount of environments in order to loop enough times
y=1;                                                        %Start environment
timeAtPoint = [];                                           %Final vector with all times per 50mm
timeAtPointTemp = [];                                       %Temp vector which will push values into the definitive timeAtPoint vector
for y = 1:allEnvironments                                   %This loop will play for every environment
    timeAtPointTemp=[trlMat(y,2) trlMat(y,1)];              %First value environment, second value environment start. 
    enterValue=longVar2(timeAtPointTemp(1,2));              %The enter value of the environment, will be used to calculate the 50mm intervals
    n=1;
    for n = 1:30                                            %Total distance of environment is 1500mm, thus 30 steps of 50mm
        i=find(longVar2>(enterValue+n.*dTime),1,'first');   %Find the first value 50mm higher than the previous
        timeAtPointTemp(end+1)=i;
    end
    timeAtPoint= [timeAtPoint; timeAtPointTemp];            %After every environment loop it will push the newly received values into this vector
    timeAtPointTemp = [];                                   %Clear the temp vector to be used again next loop. 
end

TimeAtPoint = timeAtPoint';                                 %Here I inverse the vector in order to calculate the delta in time and later sort by environment
Environments = timeAtPoint(:,1)';                           %Sorting allows us to look at negative, neutral and positive environments separately
timeBetweenPoints=diff(TimeAtPoint(2:end,:));
timeBetweenPoints=[Environments; timeBetweenPoints]';

sorted_timeBetweenPoints = sortrows(timeBetweenPoints,1);

%Sort the environments into new vectors per environment, this part returns the amount of environments each one contains.
totalEnv1Numbers = find(sorted_timeBetweenPoints==1,1,'last');  
totalEnv2Numbers = find(sorted_timeBetweenPoints==2,1,'last');
totalEnv3Numbers = find(sorted_timeBetweenPoints==3,1,'last');

%Remove environment number and sort them by environments (can also be achieved with a logical argument).
totalEnv1 = [sorted_timeBetweenPoints(1:totalEnv1Numbers,2:end)];
totalEnv2 = [sorted_timeBetweenPoints(totalEnv1Numbers+1:totalEnv2Numbers,2:end)];
totalEnv3 = [sorted_timeBetweenPoints(totalEnv2Numbers+1:totalEnv3Numbers,2:end)];
totalEnvAll = [totalEnv1; totalEnv2; totalEnv3];

%histogram with all the 50mm times, allowing us to select a time for sleep and a time for freeze.
%This requires a fresh run, else values will have been removed by code later on.
figure('name', 'Freeze/sleep times','NumberTitle','off');
hist(totalEnvAll);
title('Freeze/sleep times');

%% Find the average speed the mouse travels after a sound has been played
%Find how many packets are present in the trial (Packet size is determined at the start of the script)
packetAmount = floor(size(longVar2,1)/packetSize);

%Calculate the diff between each packet and see if it is higher than 0 (thus movement has happened)
%This can later on be used to determine average speed, without the freezes.
packetsWithMovement = []; 
n=1;
for n=1:packetAmount
    packetsWithMovementTemp = sum(diff(longVar2(1+(n-1)*packetSize:n*packetSize)))>0;
    packetsWithMovement = [packetsWithMovement packetsWithMovementTemp];
end

%Look to see if the mouse walked backwards (jumped back in fear)
%Sound onset is approximately 2s/2000ms
placesWithSounds=~isnan(trlMat(:,3));

%Here we will look at the leap backwards. We take the start of the sound and look as long as our cutoff time (which is much
%later than we would expect a leap backwards at the 6s currently). In case the cutofftime is reduced to much lower take the
%sound onset time into consideration (currently around 2s).
timesWithSounds = trlMat(placesWithSounds,3);
timesWithSounds = [timesWithSounds, timesWithSounds+cutOffTime];

%From here on we will start mapping the place over time from the moment the sound has been played 
%untill x seconds later (cutoff time)
locationDuringSounds = [];
n=1;
for n=1:sum(placesWithSounds)
    locationDuringSoundsTemp = longVar2(timesWithSounds(n,1):timesWithSounds(n,2));
    locationDuringSounds = [locationDuringSounds, locationDuringSoundsTemp];
end

locationDuringSoundsGraph = [];
n=1;
for n=1:size(locationDuringSounds(1,:),2)
    reductionFactor = locationDuringSounds(1,n);
    locationDuringSoundsGraphTemp = locationDuringSounds(:,n) - reductionFactor;
    locationDuringSoundsGraph = [locationDuringSoundsGraph locationDuringSoundsGraphTemp];
end

%Find 500ms packets of movement after sound onset
packetsWithMovementDuringSound = [];
packetsWithMovementDuringSoundTemp = [];
n=1;
y=1;
for y=1:sum(placesWithSounds)
    for n=1:(cutOffTime/packetSize)
        packetsWithMovementDuringSoundTempTemp = sum(abs(diff(longVar2((timesWithSounds(y,1)+(n-1)*packetSize):(timesWithSounds(y,1)+(n*(packetSize)-1))))))>0;
        packetsWithMovementDuringSoundTemp = [packetsWithMovementDuringSoundTemp, packetsWithMovementDuringSoundTempTemp];
    end
    n=1;
    packetsWithMovementDuringSound = [packetsWithMovementDuringSound; packetsWithMovementDuringSoundTemp];
    packetsWithMovementDuringSoundTemp = [];
end

%Average speed during moving packets
averageSpeedDuringSound = [];
averageSpeedDuringSoundTemp = [];
y=1;
for y=1:sum(placesWithSounds)
    averageSpeedDuringSoundTemp = double((longVar2(timesWithSounds(y,2))-longVar2(timesWithSounds(y,1))))/(cutOffTime*((sum(packetsWithMovementDuringSound(y,:)))./size(packetsWithMovementDuringSound(y,:),2)));
    averageSpeedDuringSound = [averageSpeedDuringSound, averageSpeedDuringSoundTemp];
end

averageSpeedDuringSound = [Environments(placesWithSounds); averageSpeedDuringSound.*10000]; %convert to cm per second

%Print the value onto the command window
disp('The average speed (cm/sec) of the mouse during sound, per environment was:')
format longG;
disp(round(averageSpeedDuringSound))

%% See if any backwards movement has happened (needs to be manually unsuppressed/checked
%Sort fear distances per environment
unsortedLocationDuringSounds = [Environments(placesWithSounds);locationDuringSoundsGraph];
UnsortedLocationDuringSounds = unsortedLocationDuringSounds';
SortedLocationDuringSounds = sortrows(UnsortedLocationDuringSounds);
sortedLocationDuringSounds = SortedLocationDuringSounds';

sortedLocationDuringSoundsEnv1 = [sortedLocationDuringSounds(1:totalEnv1Numbers,2:end)];
sortedLocationDuringSoundsEnv2 = [sortedLocationDuringSounds(totalEnv1Numbers+1:totalEnv2Numbers,2:end)];
sortedLocationDuringSoundsEnv3 = [sortedLocationDuringSounds(totalEnv2Numbers+1:totalEnv3Numbers,2:end)];
totalEnvAll = [totalEnv1;totalEnv2;totalEnv3];

% figure; hold on
% plot (locationDuringSoundsGraph)

locationDuringSoundsGraph = locationDuringSounds - locationDuringSounds;
deltaMovementDuringSounds = diff(locationDuringSounds);

backwardsMovement = times(double(deltaMovementDuringSounds),double((deltaMovementDuringSounds < 0)));

%Check backwards movement per environment
totalBackwardsMovement = sum(backwardsMovement);

% %global backwards check
deltaMovementCheck = diff(longVar2);
backwardsMovementCheck = times(double(deltaMovementCheck),double((deltaMovementCheck < 0)));
totalBackwardsCheck = sum(backwardsMovementCheck);

if totalBackwardsCheck == 0
    disp('no backwards movement has occured.')
else
    disp('backwards movement has occured.')
    disp(totalBackwardsCheck)
end

%% Plot the average time it takes the mouse to traverse each bin. 
%Values greater than the cutoff time are transformed into NaNs, allowing us to not use them for the average
exclusionValues1=find(abs(totalEnv1)>cutOffTime);
totalEnv1(exclusionValues1) = NaN;
totalEnv1cms = (5./(totalEnv1./1000));

exclusionValues2=find(abs(totalEnv2)>cutOffTime);
totalEnv2(exclusionValues2) = NaN;
totalEnv2cms = (5./(totalEnv2./1000));

exclusionValues3=find(abs(totalEnv3)>cutOffTime);
totalEnv3(exclusionValues3) = NaN;
totalEnv3cms = (5./(totalEnv3./1000));

exclusionValuesAll=find(abs(totalEnvAll)>cutOffTime);
totalEnvAll(exclusionValuesAll) = NaN;
totalEnvAllcms = (5./(totalEnvAll./1000));

%Omitnan calculates the mean while excluding the NaNs
% Plot 8 graphs (2 sets of 4). 4 line plots and 4 bar plots all containing the average time per bin
lightBlue = [91, 207, 244] / 255;
figure1 = figure('name', 'Mean time per bin with SD Environment 1','NumberTitle','off');
meanTimeEnv1 = mean(totalEnv1cms,1,"omitnan");
meanTimeEnv1x = 1:numel(meanTimeEnv1);
stdTimeEnv1 = std(totalEnv1cms,0,"omitnan");
stdTimeEnv1Curve1 = meanTimeEnv1 + stdTimeEnv1;
stdTimeEnv1Curve2 = meanTimeEnv1 - stdTimeEnv1;
meanTimeEnv1x2 = [meanTimeEnv1x, fliplr(meanTimeEnv1x)];
meanTimeEnv1InBetween = [stdTimeEnv1Curve1, fliplr(stdTimeEnv1Curve2)];
fill(meanTimeEnv1x2, meanTimeEnv1InBetween, lightBlue);
hold on;
plot(meanTimeEnv1);
title('Mean time per bin with SD Environment 1');
xline(13.5) 

figure('name', 'Mean time per bin with SD Environment 2','NumberTitle','off');
meanTimeEnv2 = mean(totalEnv2cms,1,"omitnan");
meanTimeEnv2x = 1:numel(meanTimeEnv2);
stdTimeEnv2 = std(totalEnv2cms,0,"omitnan");
stdTimeEnv2Curve1 = meanTimeEnv2 + stdTimeEnv2;
stdTimeEnv2Curve2 = meanTimeEnv2 - stdTimeEnv2;
meanTimeEnv2x2 = [meanTimeEnv2x, fliplr(meanTimeEnv2x)];
meanTimeEnv2InBetween = [stdTimeEnv2Curve1, fliplr(stdTimeEnv2Curve2)];
fill(meanTimeEnv2x2, meanTimeEnv2InBetween, lightBlue);
hold on;
plot(meanTimeEnv2);
title('Mean time per bin with SD Environment 2');
xline(13.5) 

figure('name', 'Mean time per bin with SD Environment 3','NumberTitle','off');
meanTimeEnv3 = mean(totalEnv3cms,1,"omitnan");
meanTimeEnv3x = 1:numel(meanTimeEnv3);
stdTimeEnv3 = std(totalEnv3cms,0,"omitnan");
stdTimeEnv3Curve1 = meanTimeEnv3 + stdTimeEnv3;
stdTimeEnv3Curve2 = meanTimeEnv3 - stdTimeEnv3;
meanTimeEnv3x2 = [meanTimeEnv3x, fliplr(meanTimeEnv3x)];
meanTimeEnv3InBetween = [stdTimeEnv3Curve1, fliplr(stdTimeEnv3Curve2)];
fill(meanTimeEnv3x2, meanTimeEnv3InBetween, lightBlue);
hold on;
plot(meanTimeEnv3);
title('Mean time per bin with SD Environment 3');
xline(13.5) 

meanTimeEnvAll = mean(totalEnvAllcms,1,"omitnan");
meanTimeEnvAllx = 1:numel(meanTimeEnvAll);
stdTimeEnvAll = std(totalEnvAllcms,0,"omitnan");
stdTimeEnvAllCurve1 = meanTimeEnvAll + stdTimeEnvAll;
stdTimeEnvAllCurve2 = meanTimeEnvAll - stdTimeEnvAll;
meanTimeEnvAllx2 = [meanTimeEnvAllx, fliplr(meanTimeEnvAllx)];
meanTimeEnvAllInBetween = [stdTimeEnvAllCurve1, fliplr(stdTimeEnvAllCurve2)];

figure('name', 'Mean time per bin with SD All environments','NumberTitle','off');
fill(meanTimeEnvAllx2, meanTimeEnvAllInBetween, lightBlue);
hold on;
plot(meanTimeEnvAll);
title('Mean time per bin with SD All environments');
xline(13.5) 


meanTimes = [meanTimeEnv1; meanTimeEnv2; meanTimeEnv3];
maxValue = ceil(max(meanTimes,[] , 'all', 'omitnan'));
minValue = floor(min(meanTimes,[] , 'all', 'omitnan'));

createfigurepart1(meanTimeEnv1, color1iPart1, 'Mean time per bin environment 1')
createfigurepart1(meanTimeEnv2, color2iPart1, 'Mean time per bin environment 2')
createfigurepart1(meanTimeEnv3, color3iPart1, 'Mean time per bin environment 3')

createfiguretotal(totalEnvAllcms, colorGeneral, 'Histogram: Cm/s per bin all environments', NaN, NaN)
createfiguretotal(totalEnvAll, colorGeneral, 'Histogram: Mean time per bin per environments', NaN, NaN)
createfiguretotal(meanTimeEnvAll, colorGeneral, 'Histogram: Mean time per bin all environments', NaN, NaN)


%% Find the places where the mouse freezes and for how long.
startPart1Loc = [];
startPart2Loc = [];
endPart1Loc = [];
endPart2Loc = [];

%Find the time where the adjusted environment starts (including the tunnel at start and end)
y=1;
for y=1:size(startEnv,1)
    startPart1LocTemp = find(longVar2==(startEnv(y)-100),1,'first');
    startPart1Loc = [startPart1Loc startPart1LocTemp];
    endPart1LocTemp = find(longVar2==(startEnv(y)+1550),1,'first');
    endPart1Loc = [endPart1Loc endPart1LocTemp];
    startPart2LocTemp = find(longVar2==(startRew(y)-50),1,'first');
    startPart2Loc = [startPart2Loc startPart2LocTemp];
    endPart2LocTemp = find(longVar2==(startRew(y)+350),1,'first');
    endPart2Loc = [endPart2Loc endPart2LocTemp];
end

timePerEnvBinPart1 = [];
timePerEnvBinPart2 = [];
timePerEnvBinPart1Temp = [];
timePerEnvBinPart2Temp = [];
binsEnvPart1 = (envPart1Size / dTime) + 1;
binsEnvPart2 = (envPart2Size / dTime) + 1;

envsSpeed = size(startPart1Loc,2);
y=1;
n=1;
m=1;
for y=1:envsSpeed
    for n=1:binsEnvPart1
        timePerEnvBinPart1TempTemp = find(longVar2==((startEnv(y)-100+((n-1)*50))),1,'first');
        timePerEnvBinPart1Temp = [timePerEnvBinPart1Temp timePerEnvBinPart1TempTemp];
    end
    timePerEnvBinPart1 = [timePerEnvBinPart1; timePerEnvBinPart1Temp];
    timePerEnvBinPart1Temp = [];
    for m=1:binsEnvPart2
        timePerEnvBinPart2TempTemp = find(longVar2==((startRew(y)-50+((m-1)*50))),1,'first');
        timePerEnvBinPart2Temp = [timePerEnvBinPart2Temp timePerEnvBinPart2TempTemp];
    end
    timePerEnvBinPart2 = [timePerEnvBinPart2; timePerEnvBinPart2Temp];
    timePerEnvBinPart2Temp = [];
end

%% IS THIS CODE USED?
diffNotSecondsTimePerEnvBinPart1 = diff(timePerEnvBinPart1,1,2);
diffNotSecondsTimePerEnvBinPart2 = diff(timePerEnvBinPart2,1,2);

speedPerEnvBinPart1 = 5./(diffNotSecondsTimePerEnvBinPart1./1000);
speedPerEnvBinPart2 = 5./(diffNotSecondsTimePerEnvBinPart2./1000);

%%
freezePart1 = {};
y=1;
for y=1:envsSpeed
    freezePart1{y} = longVar2(startPart1Loc(y):endPart1Loc(y));
    freezePart2{y} = longVar2(startPart2Loc(y):endPart2Loc(y));
end

freezeBinsPart1 = {};
freezeBinsPart2 = {};
y=1;
for y=1:envsSpeed
    freezeBinsPart1{y} = diff(freezePart1{y}(1:dTime:end),1);
    freezeBinsPart2{y} = diff(freezePart2{y}(1:dTime:end),1);
end

y=1;
for y=1:envsSpeed
    freezeBinsPart1Zeros{y} = (~diff(freezePart1{y}(1:dTime:end),1));
    freezeBinsPart2Zeros{y} = (~diff(freezePart2{y}(1:dTime:end),1));
end

y=1;
z = max(size(freezeBinsPart1Zeros));
for y=1:z
    FreezeBinsPart1Zeros{y} = freezeBinsPart1Zeros{y}';
    FreezeBinsPart2Zeros{y} = freezeBinsPart2Zeros{y}';
end


startOnSetOnesPart1 = {};
startOnSetZerosPart1 = {};
startOnSetOnesPart2 = {};
startOnSetZerosPart2 = {};

y=1;
z = max(size(FreezeBinsPart1Zeros));
for y=1:z
    startOnSetOnesPart1{y} = strfind(FreezeBinsPart1Zeros{y}, [0, 1]);
    startOnSetOnesPart1{y} = startOnSetOnesPart1{y}+1;                      %We want the location of the 1, strfind will give us the location of the 0
    startOnSetZerosPart1{y} = strfind(FreezeBinsPart1Zeros{y}, [1, 0]);
    startOnSetZerosPart1{y} = startOnSetZerosPart1{y}+1;                    %Same as above, we now want the 0 instead of the 1
    startOnSetOnesPart2{y} = strfind(FreezeBinsPart2Zeros{y}, [0, 1]);
    startOnSetOnesPart2{y} = startOnSetOnesPart2{y}+1;
    startOnSetZerosPart2{y} = strfind(FreezeBinsPart2Zeros{y}, [1, 0]);
    startOnSetZerosPart2{y} = startOnSetZerosPart2{y}+1;
end

%Look for the specific time where the freeze has occured
y=1;
z=max(size(FreezeBinsPart1Zeros));
for y=1:z                                                                   %Make sure the first value is a move rather than a stop (you cannot enter an environment standing still)
    if startOnSetOnesPart1{y}(1) > startOnSetZerosPart1{y}(1)
        startOnSetOnesPart1{y} = [1 startOnSetOnesPart1{y}];
    end
end

y=1;
z=max(size(FreezeBinsPart2Zeros));
for y=1:z                                                                   %Make sure the first value is a move rather than a stop (you cannot enter an environment standing still)
    if startOnSetOnesPart2{y}(1) > startOnSetZerosPart2{y}(1)
        startOnSetOnesPart2{y} = [1 startOnSetOnesPart2{y}];
    end
end

y=1;                                                                        %Matlab does not compute values of different sizes, this makes sure that both values are same length
z = max(size(FreezeBinsPart1Zeros));
for y=1:z
    if max(size(startOnSetOnesPart1{y})) > max(size(startOnSetZerosPart1{y}))
        startOnSetOnesPart1{y}(end) = [];
    end
    if max(size(startOnSetOnesPart2{y})) > max(size(startOnSetZerosPart2{y}))
        startOnSetOnesPart2{y}(end) = [];
    end    
    if max(size(startOnSetOnesPart1{y})) < max(size(startOnSetZerosPart1{y}))
        startOnSetZerosPart1{y}(end) = [];
    end
    if max(size(startOnSetOnesPart2{y})) < max(size(startOnSetZerosPart2{y}))
        startOnSetZerosPart2{y}(end) = [];
    end
end

y=1;
z = max(size(FreezeBinsPart1Zeros));
for y=1:z
    freezeDurationPart1{y} = startOnSetZerosPart1{y} - startOnSetOnesPart1{y};
    freezeDurationPart2{y} = startOnSetZerosPart2{y} - startOnSetOnesPart2{y};
end

y=1;
z = max(size(FreezeBinsPart1Zeros));
for y=1:z
    freezePlacesPart1{y} = find(freezeDurationPart1{y} > (0.5/(dTime/1000)) & freezeDurationPart1{y} < ((cutOffTime/1000)/(dTime/1000)));
    freezePlacesPart2{y} = find(freezeDurationPart2{y} > (0.5/(dTime/1000)) & freezeDurationPart2{y} < ((cutOffTime/1000)/(dTime/1000)));
end

%Isolate these times
y=1;
for y = 1:max(size(freezeDurationPart1));
    freezePlacesPart1Isolated{y} = freezeDurationPart1{y}(freezePlacesPart1{y});
    freezePlacesPart2Isolated{y} = freezeDurationPart2{y}(freezePlacesPart2{y});
end

%For part 1
freezeTimeBinsPart1 = {};
freezeTimeBinsPart1Temp = [];
y=1;
for y=1:max(size(startOnSetOnesPart1))
    n=1;
    if isempty(freezePlacesPart1{y})
        freezeTimeBinsPart1{y} = [];
    else
        for n=1:max(size(freezePlacesPart1{y}))
            freezeTimeBinsPart1TempTemp = startOnSetOnesPart1{y}(freezePlacesPart1{y}(n));
            freezeTimeBinsPart1Temp = [freezeTimeBinsPart1Temp freezeTimeBinsPart1TempTemp];
        end
    end
    freezeTimeBinsPart1{y} = freezeTimeBinsPart1Temp;
    freezeTimeBinsPart1Temp = [];
end

%For part 2
freezeTimeBinsPart2 = {};
freezeTimeBinsPart2Temp = [];
y=1;
for y=1:max(size(startOnSetOnesPart2))
    n=1;
    if isempty(freezePlacesPart2{y})
        freezeTimeBinsPart2{y} = [];
    else
        for n=1:max(size(freezePlacesPart2{y}))
            freezeTimeBinsPart2TempTemp = startOnSetOnesPart2{y}(freezePlacesPart2{y}(n));
            freezeTimeBinsPart2Temp = [freezeTimeBinsPart2Temp freezeTimeBinsPart2TempTemp];
        end
    end
    freezeTimeBinsPart2{y} = freezeTimeBinsPart2Temp;
    freezeTimeBinsPart2Temp = [];
end


%Find relative freeze position from start
%For part 1
freezePositionPart1 = {};
freezePositionPart1Temp = [];
y=1;
for y=1:max(size(freezeTimeBinsPart1))
    n=1;
    if isempty(freezeTimeBinsPart1{y});
        freezePositionPart1{y} = [];
    else
        for n=1:max(size(freezeTimeBinsPart1{y}))
        freezePositionPart1TempTemp = longVar2(startPart1Loc(y) + (freezeTimeBinsPart1{y}(n).*dTime));
        freezePositionPart1Temp = [freezePositionPart1Temp freezePositionPart1TempTemp];
        end
        freezePositionPart1{y} = (freezePositionPart1Temp - startStartEnv(y));
        freezePositionPart1Temp = [];
    end
end

%For part 2
freezePositionPart2 = {};
freezePositionPart2Temp = [];
y=1;
for y=1:max(size(freezeTimeBinsPart2))
    n=1;
    if isempty(freezeTimeBinsPart2{y})
        freezePositionPart2{y} = [];
    else
        for n=1:max(size(freezeTimeBinsPart2{y}))
        freezePositionPart2TempTemp = longVar2(startPart2Loc(y) + (freezeTimeBinsPart2{y}(n).*dTime));
        freezePositionPart2Temp = [freezePositionPart2Temp freezePositionPart2TempTemp];
        end
        freezePositionPart2{y} = (freezePositionPart2Temp - startStartRew(y));
        freezePositionPart2Temp = [];
    end
end

EnvironmentsCorrected = Environments(2:end);

% Combine freezes per environment per part
% Environment 1
freezePositionPart1Environment1 = freezePositionPart1(EnvironmentsCorrected == 1);
freezePositionPart1Environment1 = freezePositionPart1Environment1(~cellfun('isempty', freezePositionPart1Environment1));
freezePositionPart1Environment1 = cell2mat(freezePositionPart1Environment1);

freezePositionPart2Environment1 = freezePositionPart2(EnvironmentsCorrected == 1);
freezePositionPart2Environment1 = freezePositionPart2Environment1(~cellfun('isempty', freezePositionPart2Environment1));
freezePositionPart2Environment1 = cell2mat(freezePositionPart2Environment1);

% Environment 2
freezePositionPart1Environment2 = freezePositionPart1(EnvironmentsCorrected == 2);
freezePositionPart1Environment2 = freezePositionPart1Environment2(~cellfun('isempty', freezePositionPart1Environment2));
freezePositionPart1Environment2 = cell2mat(freezePositionPart1Environment2);

freezePositionPart2Environment2 = freezePositionPart2(EnvironmentsCorrected == 2);
freezePositionPart2Environment2 = freezePositionPart2Environment2(~cellfun('isempty', freezePositionPart2Environment2));
freezePositionPart2Environment2 = cell2mat(freezePositionPart2Environment2);

% Environment 3
freezePositionPart1Environment3 = freezePositionPart1(EnvironmentsCorrected == 3);
freezePositionPart1Environment3 = freezePositionPart1Environment3(~cellfun('isempty', freezePositionPart1Environment3));
freezePositionPart1Environment3 = cell2mat(freezePositionPart1Environment3);

freezePositionPart2Environment3 = freezePositionPart2(EnvironmentsCorrected == 3);
freezePositionPart2Environment3 = freezePositionPart2Environment3(~cellfun('isempty', freezePositionPart2Environment3));
freezePositionPart2Environment3 = cell2mat(freezePositionPart2Environment3);

% Combine freezes per environment per part
% Environment 1
freezeLengthPart1IsolatedEnvironment1 = freezePlacesPart1Isolated(EnvironmentsCorrected == 1);
freezeLengthPart1IsolatedEnvironment1 = freezeLengthPart1IsolatedEnvironment1(~cellfun('isempty', freezeLengthPart1IsolatedEnvironment1));
freezeLengthPart1IsolatedEnvironment1 = cell2mat(freezeLengthPart1IsolatedEnvironment1);

freezeLengthPart2IsolatedEnvironment1 = freezePlacesPart2Isolated(EnvironmentsCorrected == 1);
freezeLengthPart2IsolatedEnvironment1 = freezeLengthPart2IsolatedEnvironment1(~cellfun('isempty', freezeLengthPart2IsolatedEnvironment1));
freezeLengthPart2IsolatedEnvironment1 = cell2mat(freezeLengthPart2IsolatedEnvironment1);

% Environment 2
freezeLengthPart1IsolatedEnvironment2 = freezePlacesPart1Isolated(EnvironmentsCorrected == 2);
freezeLengthPart1IsolatedEnvironment2 = freezeLengthPart1IsolatedEnvironment2(~cellfun('isempty', freezeLengthPart1IsolatedEnvironment2));
freezeLengthPart1IsolatedEnvironment2 = cell2mat(freezeLengthPart1IsolatedEnvironment2);

freezeLengthPart2IsolatedEnvironment2 = freezePlacesPart2Isolated(EnvironmentsCorrected == 2);
freezeLengthPart2IsolatedEnvironment2 = freezeLengthPart2IsolatedEnvironment2(~cellfun('isempty', freezeLengthPart2IsolatedEnvironment2));
freezeLengthPart2IsolatedEnvironment2 = cell2mat(freezeLengthPart2IsolatedEnvironment2);

% Environment 3
freezeLengthPart1IsolatedEnvironment3 = freezePlacesPart1Isolated(EnvironmentsCorrected == 3);
freezeLengthPart1IsolatedEnvironment3 = freezeLengthPart1IsolatedEnvironment3(~cellfun('isempty', freezeLengthPart1IsolatedEnvironment3));
freezeLengthPart1IsolatedEnvironment3 = cell2mat(freezeLengthPart1IsolatedEnvironment3);

freezeLengthPart2IsolatedEnvironment3 = freezePlacesPart2Isolated(EnvironmentsCorrected == 3);
freezeLengthPart2IsolatedEnvironment3 = freezeLengthPart2IsolatedEnvironment3(~cellfun('isempty', freezeLengthPart2IsolatedEnvironment3));
freezeLengthPart2IsolatedEnvironment3 = cell2mat(freezeLengthPart2IsolatedEnvironment3);

%Combine into one
freezeLengthIsolatedEnvironment1 = [freezeLengthPart1IsolatedEnvironment1 freezeLengthPart2IsolatedEnvironment1];
freezeLengthIsolatedEnvironment2 = [freezeLengthPart1IsolatedEnvironment2 freezeLengthPart2IsolatedEnvironment2];
freezeLengthIsolatedEnvironment3 = [freezeLengthPart1IsolatedEnvironment3 freezeLengthPart2IsolatedEnvironment3];

binnedFreezePositionPart1Environment1 = discretize(freezePositionPart1Environment1, edgesPart1);
binnedFreezePositionPart1Environment2 = discretize(freezePositionPart1Environment2, edgesPart1);
binnedFreezePositionPart1Environment3 = discretize(freezePositionPart1Environment3, edgesPart1);

binnedFreezePositionPart2Environment1 = discretize(freezePositionPart2Environment1, edgesPart1);
binnedFreezePositionPart2Environment2 = discretize(freezePositionPart2Environment2, edgesPart1);
binnedFreezePositionPart2Environment3 = discretize(freezePositionPart2Environment3, edgesPart1);

binnedFreezePositionEnvironment1 = [(binnedFreezePositionPart1Environment1 - 2) (binnedFreezePositionPart2Environment1 + 31)];
binnedFreezePositionEnvironment2 = [(binnedFreezePositionPart1Environment2 - 2) (binnedFreezePositionPart2Environment2 + 31)];
binnedFreezePositionEnvironment3 = [(binnedFreezePositionPart1Environment3 - 2) (binnedFreezePositionPart2Environment3 + 31)];

%Plot binned freeze positions over time.
y1 = freezeLengthIsolatedEnvironment1/(1000/dTime); %Divide by 4 to convert it to seconds (currently 250ms packets used)
y2 = freezeLengthIsolatedEnvironment2/(1000/dTime);
y3 = freezeLengthIsolatedEnvironment3/(1000/dTime);

%Plot binned freeze positions per count
x1 = binnedFreezePositionEnvironment1.*dTime;
x2 = binnedFreezePositionEnvironment2.*dTime;
x3 = binnedFreezePositionEnvironment3.*dTime;


figure('name', 'Freeze environment 1','NumberTitle','off');;
s1 = subplot(3,1,1);
s1.Position = [0.1300 0.6285 0.7750 0.3000];
histogram(x1, 'BinEdges',edges);
grid on;
xlim([low, high]);
title('Freeze count environment 1');

s2 = subplot(3,1,2);
s2.Position = [0.1300 0.5096 0.7750 0.0350];
image(color1i);
ylim([5, 10]);
axis off;

s3 = subplot(3,1,3);
s3.Position = [0.1300 0.1100 0.7750 0.3157];
xx1 = min(x1):max(x1);
nxx1 = numel(xx1);
counts = histcounts(x1,nxx1);
yy1 = NaN(max(counts),nxx1);
for ii = 1:nxx1
    yy1(1:counts(ii),ii) = y1(x1 == xx1(ii));
end
bar((xx1+(dTime*0.5)), yy1, dTime, 'stacked')
grid on;
xlim([low, high]);
title('Freeze duration environment 1');


figure('name', 'Freeze environment 2','NumberTitle','off');;
s1 = subplot(3,1,1);
s1.Position = [0.1300 0.6285 0.7750 0.3000];
histogram(x2, 'BinEdges',edges);
grid on;
xlim([low, high]);
title('Freeze count environment 2');

s2 = subplot(3,1,2);
s2.Position = [0.1300 0.5096 0.7750 0.0350];
image(color2i);
ylim([5, 10]);
axis off;

s3 = subplot(3,1,3);
s3.Position = [0.1300 0.1100 0.7750 0.3157];
xx2 = min(x2):max(x2);
nxx2 = numel(xx2);
counts = histcounts(x2,nxx2);
yy2 = NaN(max(counts),nxx2);
for ii = 1:nxx2
    yy2(1:counts(ii),ii) = y2(x2 == xx2(ii));
end
bar((xx2+(dTime*0.5)), yy2, dTime, 'stacked')
grid on;
xlim([low, high]);
title('Freeze duration environment 2');


figure('name', 'Freeze environment 3','NumberTitle','off');;
s1 = subplot(3,1,1);
s1.Position = [0.1300 0.6285 0.7750 0.3000];
histogram(x3, 'BinEdges',edges);
grid on;
xlim([low, high]);
title('Freeze count environment 3');

s2 = subplot(3,1,2);
s2.Position = [0.1300 0.5096 0.7750 0.0350];
image(color3i);
ylim([5, 10]);
axis off;

s3 = subplot(3,1,3);
s3.Position = [0.1300 0.1100 0.7750 0.3157];
xx3 = min(x3):max(x3);
nxx3 = numel(xx3);
counts = histcounts(x3,nxx3);
yy3 = NaN(max(counts),nxx3);
for ii = 1:nxx3
    yy3(1:counts(ii),ii) = y3(x3 == xx3(ii));
end
bar((xx3+(dTime*0.5)), yy3, dTime, 'stacked')
grid on;
xlim([low, high]);
title('Freeze duration environment 3');

%Total time frozen
EnvironmentsCorrectedCorrected = Environments(2:end-1); %Last environment will have a lot of idle time to due ending the experiment, therefore it is excluded
timePerEnv = trlMat(2:end-1,5)-trlMat(2:end-1,1); %Time taken per environment
freezePercentageEnvironment1 = sum(freezeLengthIsolatedEnvironment1*dTime)./sum(timePerEnv(EnvironmentsCorrectedCorrected==1));
freezePercentageEnvironment2 = sum(freezeLengthIsolatedEnvironment2*dTime)./sum(timePerEnv(EnvironmentsCorrectedCorrected==2));
freezePercentageEnvironment3 = sum(freezeLengthIsolatedEnvironment3*dTime)./sum(timePerEnv(EnvironmentsCorrectedCorrected==3));

freezePercentageAll = [freezePercentageEnvironment1 freezePercentageEnvironment2 freezePercentageEnvironment3];

%Total time stood still
FreezeDurationEnvironment1 = cell2mat([freezeDurationPart1(EnvironmentsCorrectedCorrected == 1) freezeDurationPart2(EnvironmentsCorrectedCorrected == 1)]);
FreezeDurationEnvironment2 = cell2mat([freezeDurationPart1(EnvironmentsCorrectedCorrected == 2) freezeDurationPart2(EnvironmentsCorrectedCorrected == 2)]);
FreezeDurationEnvironment3 = cell2mat([freezeDurationPart1(EnvironmentsCorrectedCorrected == 3) freezeDurationPart2(EnvironmentsCorrectedCorrected == 3)]);

stillPercentageEnvironment1 = sum(FreezeDurationEnvironment1*dTime)./sum(endPart2Loc(EnvironmentsCorrectedCorrected == 1) - startPart1Loc(EnvironmentsCorrectedCorrected == 1));
stillPercentageEnvironment2 = sum(FreezeDurationEnvironment2*dTime)./sum(endPart2Loc(EnvironmentsCorrectedCorrected == 2) - startPart1Loc(EnvironmentsCorrectedCorrected == 2));
stillPercentageEnvironment3 = sum(FreezeDurationEnvironment3*dTime)./sum(endPart2Loc(EnvironmentsCorrectedCorrected == 3) - startPart1Loc(EnvironmentsCorrectedCorrected == 3));

stillPercentageAll = [stillPercentageEnvironment1 stillPercentageEnvironment2 stillPercentageEnvironment3];

stillPercentageGraph = [stillPercentageAll-freezePercentageAll ; freezePercentageAll];

figure('name', 'Freeze/sleep percentage per environment','NumberTitle','off')
subplot(2,1,1);
bar(freezePercentageAll);
text(1:length(freezePercentageAll),freezePercentageAll,num2str(freezePercentageAll',3),'vert','bottom','horiz','center'); 
title('Freeze percentage per environment');
ylim([0, max(freezePercentageAll)*1.15]);
box off

subplot(2,1,2);
bar(stillPercentageGraph', 'stacked');
text(1:length(stillPercentageAll),stillPercentageAll,num2str(stillPercentageAll',3),'vert','bottom','horiz','center'); 
title('Freeze+sleep percentage per environment');
ylim([0, max(stillPercentageAll)*1.15]);
box off

%% Another heatmap, this time with the tunnel parts and reward zone area.
%Repeat, now with reward zone (will exclude 1st environment)
y=1;
timeAtPointPart1Repeat = [];
timeAtPointPart1RepeatTemp = [];
for y = 1:max(size(startPart1Loc))                                   
    timeAtPointPart1RepeatTemp=[trlMat(y+1,2) startPart1Loc(y)];              
    n=1;
    for n=1:(envPart1Size/dTime)
        i=find(longVar2>longVar2(startPart1Loc(y))+n.*dTime,1,'first');
        timeAtPointPart1RepeatTemp(end+1) = i;
    end
    timeAtPointPart1Repeat = [timeAtPointPart1Repeat; timeAtPointPart1RepeatTemp];            
    timeAtPointPart1RepeatTemp = [];                        
end

y=1;
timeAtPointPart2Repeat = [];
timeAtPointPart2RepeatTemp = [];
for y = 1:max(size(startPart2Loc))                                   
    timeAtPointPart2RepeatTemp=[trlMat(y+1,2) startPart2Loc(y)];              
    n=1;
    for n=1:(envPart2Size/dTime)
        i=find(longVar2>longVar2(startPart2Loc(y))+n.*dTime,1,'first');
        timeAtPointPart2RepeatTemp(end+1) = i;
    end
    timeAtPointPart2Repeat = [timeAtPointPart2Repeat; timeAtPointPart2RepeatTemp];            
    timeAtPointPart2RepeatTemp = [];                        
end

dTimeAtPointPart1Repeat = [timeAtPointPart1Repeat(:,1) diff(timeAtPointPart1Repeat(:,2:end),1,2)];
dTimeAtPointPart2Repeat = [timeAtPointPart2Repeat(:,1) diff(timeAtPointPart2Repeat(:,2:end),1,2)];

dTimeAtPointRepeat = sortrows([dTimeAtPointPart1Repeat dTimeAtPointPart2Repeat(:,2:end)],1);
dTimeAtPointRepeatEnvironment1Temp = dTimeAtPointRepeat(dTimeAtPointRepeat(:,1) == 1,2:end);
dTimeAtPointRepeatEnvironment2Temp = dTimeAtPointRepeat(dTimeAtPointRepeat(:,1) == 2,2:end);
dTimeAtPointRepeatEnvironment3Temp = dTimeAtPointRepeat(dTimeAtPointRepeat(:,1) == 3,2:end);

dTimeAtPointRepeatEnvironment1 = [dTimeAtPointRepeatEnvironment1Temp; mean(dTimeAtPointRepeatEnvironment1Temp)];
dTimeAtPointRepeatEnvironment2 = [dTimeAtPointRepeatEnvironment2Temp; mean(dTimeAtPointRepeatEnvironment2Temp)];
dTimeAtPointRepeatEnvironment3 = [dTimeAtPointRepeatEnvironment3Temp; mean(dTimeAtPointRepeatEnvironment3Temp)];

minValue = ceil(5./(max(dTimeAtPointRepeat(:,2:end),[] , 'all', 'omitnan')./1000));
maxValue = floor(5./(min(dTimeAtPointRepeat(:,2:end),[] , 'all', 'omitnan')./1000));

exclusionValues1=find(abs(dTimeAtPointRepeatEnvironment1)>cutOffTime);
dTimeAtPointRepeatEnvironment1(exclusionValues3) = NaN;
dTimeAtPointRepeatEnvironment1cms = (5./(dTimeAtPointRepeatEnvironment1./1000));

exclusionValues2=find(abs(dTimeAtPointRepeatEnvironment2)>cutOffTime);
dTimeAtPointRepeatEnvironment2(exclusionValues2) = NaN;
dTimeAtPointRepeatEnvironment2cms = (5./(dTimeAtPointRepeatEnvironment2./1000));

exclusionValues3=find(abs(dTimeAtPointRepeatEnvironment3)>cutOffTime);
dTimeAtPointRepeatEnvironment3(exclusionValues3) = NaN;
dTimeAtPointRepeatEnvironment3cms = (5./(dTimeAtPointRepeatEnvironment3./1000));


createfiguretotal(dTimeAtPointRepeatEnvironment1cms, color1i, 'Heatmap: cms per bin environment 1', minValue, maxValue)
createfiguretotal(dTimeAtPointRepeatEnvironment2cms, color2i, 'Heatmap: cms per bin environment 2', minValue, maxValue)
createfiguretotal(dTimeAtPointRepeatEnvironment3cms, color3i, 'Heatmap: cms per bin environment 3', minValue, maxValue)


%% Jeroen's code
%% Whats what
% channel map

% digdital input. what we see in matlab
% 1 IR camera
% 2 Sound
% 3 Something IR camera??
% 4 Encoder
% 5 Wheel
% 6 Wheel
% 7 broken
% 8 broken
% 9 broken
% 10 broken
% 11 tunnel 2
% 12 tunnel 1
% 13 env 3
% 14 env 2
% 15 env 1          inverted
% 16 reward area


% Missing sound trigger in env 1?


%% Digital Inputs

% Load file
tempInput = double(packet.digitalIn);
% sum(digitalIn)
goodOrder=[8:-1:1 16:-1:9];
nChan = size(tempInput,2);
digitalIn = nan(size(tempInput));
for iCh = 1:nChan
    iChan = goodOrder(iCh);
    digitalIn(:,iChan) = tempInput(:,iCh);
end

nChan = size(digitalIn,2);

for iChan = 1:nChan
  dChan = diff(digitalIn(:,iChan));
  digIn.onset{iChan} = find(dChan == 1) + 1;
  digIn.offset{iChan} = find(dChan == -1);
  % we should add a boundry check
end
% what is in where?
% which have stuff: 1vid1 2vid2 3iti 8? 9scanClock 10? 13belt? 14belt? 
digIn.labels = {'empty','empty','wheelA','wheelB', ...
  'wheelC','IRcamera','sound','scanner', ...
  'reward_zone','environment1','environment2','environment3', ...
  'tunnel1','tunnel2','empty','empty'};


%% Plot stuff

figure; hold on
for iChan = [2:4 7:16]%1:nChan
  plot(digitalIn(:,iChan)+(iChan))
end

%% Digital Outputs

% Load file
tempOutput = double(packet.digitalOut);
% sum(digitalIn)
goodOrder=[8:-1:1];
nChan = size(tempOutput,2);
digitalOut = nan(size(tempOutput));
for iCh = 1:nChan
    iChan = goodOrder(iCh);
    digitalOut(:,iChan) = tempOutput(:,iCh);
end

% Load file
% digitalOut = double(packet.digitalOut);
% sum(digitalIn)

nChan = size(digitalOut,2);
for iChan = 1:nChan
  dChan = diff(digitalOut(:,iChan));
  digOut.onset{iChan} = find(dChan == 1) + 1;
  digOut.offset{iChan} = find(dChan == -1);
  % we should add a boundry check
end
% which channels have stuff 4sync?
digOut.labels = {'empty','valve','empty','empty', ...
  'barcode','empty','lick','empty'};

%% Plot stuff



figure; hold on
for iChan = [1:8]
  plot(digitalOut(:,iChan)*iChan)
end


% 1 empty
% 2 = lick
% 3 epmty
% 4 = barcode
% 5 empty
% 6 empty
% 7 = valve ?
% 8 broken


%% Plot an input and an output

figure; hold on 
plot(digitalIn(:,9),'r')
plot(digitalOut(:,2),'y')

figure; hold on
plot(longVar2)





